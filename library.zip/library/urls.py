#!/usr/bin/env python
# -*- coding: utf-8 -*-

from django.contrib.staticfiles import views as static_views
from django.conf.urls.static import static
from django.conf import settings
from django.urls import re_path

import library.views as views

urlpatterns = [
                  re_path(r'^$', views.index, name='index'),
                  re_path(r'^login/', views.user_login, name='user_login'),
                  re_path(r'^logout/', views.user_logout, name='user_logout'),
                  re_path(r'^register/', views.user_register, name='user_register'),
                  re_path(r'^set_password/', views.set_password, name='set_password'),
                  re_path(r'^static/(?P<path>.*)$', static_views.serve, name='static'),
                  re_path(r'^book/detail$', views.book_detail, name='book_detail'),
                  re_path(r'^book/action$', views.reader_operation, name='reader_operation'),
                  re_path(r'^search/', views.book_search, name='book_search'),
                  re_path(r'^profile/', views.profile, name='profile'),
                  re_path(r'^statistics/', views.statistics, name='statistics'),
                  re_path(r'^about/', views.about, name='about'),
              ] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
